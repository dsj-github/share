using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest
   {
   public class Startup
      {
      public Startup(IConfiguration configuration)
         {
         Configuration = configuration;
         } // Startup

      public IConfiguration Configuration { get; }

      // This method gets called by the runtime. Use this method to add
      // services to the container.
      public void ConfigureServices(IServiceCollection services)
         {
         services.AddDbContext<AdicionalContext>(opt =>
            opt.UseInMemoryDatabase("Adicional"));
         services.AddDbContext<PedidoContext>(opt =>
            opt.UseInMemoryDatabase("Pedido"));
         services.AddDbContext<PedidoAdicionaisContext>(opt =>
            opt.UseInMemoryDatabase("PedidoAdicionais"));
         services.AddDbContext<SaborContext>(opt =>
            opt.UseInMemoryDatabase("Sabor"));
         services.AddDbContext<TamanhoContext>(opt =>
            opt.UseInMemoryDatabase("Tamanho"));
         services.AddControllers();
         } // ConfigureServices

      // This method gets called by the runtime. Use this method to
      // configure the HTTP request pipeline.
      public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
         {
         if (env.IsDevelopment())
            {
            app.UseDeveloperExceptionPage();
            }

         app.UseHttpsRedirection();

         app.UseRouting();

         app.UseAuthorization();

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         }
            );
         } // Configure
      } // Startup
   } // namespace APITest
