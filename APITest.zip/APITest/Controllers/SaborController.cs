﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest.Controllers
   {
   [Route("api/[controller]")]
   [ApiController]

   public class SaborController : ControllerBase
      {
      private readonly SaborContext _context;

      public SaborController(SaborContext context)
         {
         _context = context;
         }

      // GET: api/Sabor
      [HttpGet]
      public async Task<ActionResult<IEnumerable<Sabor>>> GetSabor()
         {
         return await _context.Sabor.ToListAsync();
         }

      // GET: api/Sabor/5
      [HttpGet("{TBSaborID}")]
      public async Task<ActionResult<Sabor>> GetSabor(long TBSaborID)
         {
         var Sabor = await _context.Sabor.FindAsync(TBSaborID);

         if (Sabor == null)
            {
            return NotFound();
            }

         return Sabor;
         }

      // PUT: api/Sabors/5
      [HttpPut("{TBSaborID}")]
      public async Task<IActionResult> PutSabor(long TBSaborID, Sabor Sabor)
         {
         if (TBSaborID != Sabor.TBSaborID)
            {
            return BadRequest();
            }

         _context.Entry(Sabor).State = EntityState.Modified;

         try
            {
            await _context.SaveChangesAsync();
            }
         catch (DbUpdateConcurrencyException)
            {
            if (!SaborExists(TBSaborID))
               {
               return NotFound();
               }
            else
               {
               throw;
               }
            }

         return NoContent();
         }

      // POST: api/Sabor+
      [HttpPost]
      public async Task<ActionResult<Sabor>> PostSabor(Sabor Sabor)
         {
         _context.Sabor.Add(Sabor);
         await _context.SaveChangesAsync();

         return CreatedAtAction(nameof(GetSabor), new { TBSaborID = Sabor.TBSaborID }, Sabor);
         }

      // DELETE: api/Sabors/5
      [HttpDelete("{TBSaborID}")]
      public async Task<ActionResult<Sabor>> DeleteSabor(long TBSaborID)
         {
         var Sabor = await _context.Sabor.FindAsync(TBSaborID);
         if (Sabor == null)
            {
            return NotFound();
            }

         _context.Sabor.Remove(Sabor);
         await _context.SaveChangesAsync();

         return Sabor;
         }

      private bool SaborExists(long TBSaborID)
         {
         return _context.Sabor.Any(e => e.TBSaborID == TBSaborID);
         }

      } // SaborsController

   } // APITest.Controllers
