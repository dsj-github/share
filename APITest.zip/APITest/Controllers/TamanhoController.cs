﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest.Controllers
   {
   [Route("api/[controller]")]
   [ApiController]

   public class TamanhoController : ControllerBase
      {
      private readonly TamanhoContext _context;

      public TamanhoController(TamanhoContext context)
         {
         _context = context;
         }

      // GET: api/Tamanho
      [HttpGet]
      public async Task<ActionResult<IEnumerable<Tamanho>>> GetTamanho()
         {
         return await _context.Tamanho.ToListAsync();
         }

      // GET: api/Tamanho/5
      [HttpGet("{TBTamanhoID}")]
      public async Task<ActionResult<Tamanho>> GetTamanho(long TBTamanhoID)
         {
         var Tamanho = await _context.Tamanho.FindAsync(TBTamanhoID);

         if (Tamanho == null)
            {
            return NotFound();
            }

         return Tamanho;
         }

      // PUT: api/Tamanho/5
      [HttpPut("{TBTamanhoID}")]
      public async Task<IActionResult> PutTamanho(long TBTamanhoID, Tamanho Tamanho)
         {
         if (TBTamanhoID != Tamanho.TBTamanhoID)
            {
            return BadRequest();
            }

         _context.Entry(Tamanho).State = EntityState.Modified;

         try
            {
            await _context.SaveChangesAsync();
            }
         catch (DbUpdateConcurrencyException)
            {
            if (!TamanhoExists(TBTamanhoID))
               {
               return NotFound();
               }
            else
               {
               throw;
               }
            }

         return NoContent();
         }

      // POST: api/Tamanho+
      [HttpPost]
      public async Task<ActionResult<Tamanho>> PostTamanho(Tamanho Tamanho)
         {
         _context.Tamanho.Add(Tamanho);
         await _context.SaveChangesAsync();

         return CreatedAtAction(nameof(GetTamanho), new { TBTamanhoID = Tamanho.TBTamanhoID }, Tamanho);
         }

      // DELETE: api/Tamanho/5
      [HttpDelete("{TBTamanhoID}")]
      public async Task<ActionResult<Tamanho>> DeleteTamanho(long TBTamanhoID)
         {
         var Tamanho = await _context.Tamanho.FindAsync(TBTamanhoID);
         if (Tamanho == null)
            {
            return NotFound();
            }

         _context.Tamanho.Remove(Tamanho);
         await _context.SaveChangesAsync();

         return Tamanho;
         }

      private bool TamanhoExists(long TBTamanhoID)
         {
         return _context.Tamanho.Any(e => e.TBTamanhoID == TBTamanhoID);
         }

      } // TamanhoController

   } // APITest.Controllers
