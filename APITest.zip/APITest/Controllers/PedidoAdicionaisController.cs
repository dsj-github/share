﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest.Controllers
   {
   [Route("api/[controller]")]
   [ApiController]

   public class PedidoAdicionaisController : ControllerBase
      {
      private readonly PedidoAdicionaisContext _context;

      public PedidoAdicionaisController(PedidoAdicionaisContext context)
         {
         _context = context;
         }

      // GET: api/PedidoAdicionais
      [HttpGet]
      public async Task<ActionResult<IEnumerable<PedidoAdicionais>>> GetPedidoAdicionais()
         {
         return await _context.PedidoAdicionais.ToListAsync();
         }

      // GET: api/PedidoAdicionais/5
      [HttpGet("{TBPedidoAdicionaisID}")]
      public async Task<ActionResult<PedidoAdicionais>> GetPedidoAdicionais(long TBPedidoAdicionaisID)
         {
         var PedidoAdicionais = await _context.PedidoAdicionais.FindAsync(TBPedidoAdicionaisID);

         if (PedidoAdicionais == null)
            {
            return NotFound();
            }

         return PedidoAdicionais;
         }

      // PUT: api/PedidoAdicionaiss/5
      [HttpPut("{TBPedidoAdicionaisID}")]
      public async Task<IActionResult> PutPedidoAdicionais(long TBPedidoAdicionaisID, PedidoAdicionais PedidoAdicionais)
         {
         if (TBPedidoAdicionaisID != PedidoAdicionais.TBPedidoAdicionaisID)
            {
            return BadRequest();
            }

         _context.Entry(PedidoAdicionais).State = EntityState.Modified;

         try
            {
            await _context.SaveChangesAsync();
            }
         catch (DbUpdateConcurrencyException)
            {
            if (!PedidoAdicionaisExists(TBPedidoAdicionaisID))
               {
               return NotFound();
               }
            else
               {
               throw;
               }
            }

         return NoContent();
         }

      // POST: api/PedidoAdicionais+
      [HttpPost]
      public async Task<ActionResult<PedidoAdicionais>> PostPedidoAdicionais(PedidoAdicionais PedidoAdicionais)
         {
         _context.PedidoAdicionais.Add(PedidoAdicionais);
         await _context.SaveChangesAsync();

         return CreatedAtAction(nameof(GetPedidoAdicionais), new { TBPedidoAdicionaisID = PedidoAdicionais.TBPedidoAdicionaisID }, PedidoAdicionais);
         }

      // DELETE: api/PedidoAdicionaiss/5
      [HttpDelete("{TBPedidoAdicionaisID}")]
      public async Task<ActionResult<PedidoAdicionais>> DeletePedidoAdicionais(long TBPedidoAdicionaisID)
         {
         var PedidoAdicionais = await _context.PedidoAdicionais.FindAsync(TBPedidoAdicionaisID);
         if (PedidoAdicionais == null)
            {
            return NotFound();
            }

         _context.PedidoAdicionais.Remove(PedidoAdicionais);
         await _context.SaveChangesAsync();

         return PedidoAdicionais;
         }

      private bool PedidoAdicionaisExists(long TBPedidoAdicionaisID)
         {
         return _context.PedidoAdicionais.Any(e => e.TBPedidoAdicionaisID == TBPedidoAdicionaisID);
         }

      } // PedidoAdicionaissController

   } // APITest.Controllers
