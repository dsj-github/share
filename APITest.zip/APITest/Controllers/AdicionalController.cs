﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest.Controllers
   {
   [Route("api/[controller]")]
   [ApiController]

   public class AdicionalController : ControllerBase
      {
      private readonly AdicionalContext _context;

      public AdicionalController(AdicionalContext context)
         {
         _context = context;
         }

      // GET: api/Adicional
      [HttpGet]
      public async Task<ActionResult<IEnumerable<Adicional>>> GetAdicional()
         {
         return await _context.Adicional.ToListAsync();
         }

      // GET: api/Adicional/5
      [HttpGet("{TBAdicionalID}")]
      public async Task<ActionResult<Adicional>> GetAdicional(long TBAdicionalID)
         {
         var Adicional = await _context.Adicional.FindAsync(TBAdicionalID);

         if (Adicional == null)
            {
            return NotFound();
            }

         return Adicional;
         }

      // PUT: api/Adicionals/5
      [HttpPut("{TBAdicionalID}")]
      public async Task<IActionResult> PutAdicional(long TBAdicionalID, Adicional Adicional)
         {
         if (TBAdicionalID != Adicional.TBAdicionalID)
            {
            return BadRequest();
            }

         _context.Entry(Adicional).State = EntityState.Modified;

         try
            {
            await _context.SaveChangesAsync();
            }
         catch (DbUpdateConcurrencyException)
            {
            if (!AdicionalExists(TBAdicionalID))
               {
               return NotFound();
               }
            else
               {
               throw;
               }
            }

         return NoContent();
         }

      // POST: api/Adicional+
      [HttpPost]
      public async Task<ActionResult<Adicional>> PostAdicional(Adicional Adicional)
         {
         _context.Adicional.Add(Adicional);
         await _context.SaveChangesAsync();

         return CreatedAtAction(nameof(GetAdicional), new { TBAdicionalID = Adicional.TBAdicionalID }, Adicional);
         }

      // DELETE: api/Adicionals/5
      [HttpDelete("{TBAdicionalID}")]
      public async Task<ActionResult<Adicional>> DeleteAdicional(long TBAdicionalID)
         {
         var Adicional = await _context.Adicional.FindAsync(TBAdicionalID);
         if (Adicional == null)
            {
            return NotFound();
            }

         _context.Adicional.Remove(Adicional);
         await _context.SaveChangesAsync();

         return Adicional;
         }

      private bool AdicionalExists(long TBAdicionalID)
         {
         return _context.Adicional.Any(e => e.TBAdicionalID == TBAdicionalID);
         }

      } // AdicionalsController

   } // APITest.Controllers
