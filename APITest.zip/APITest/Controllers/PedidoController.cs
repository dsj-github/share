﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APITest.Models;

namespace APITest.Controllers
   {
   [Route("api/[controller]")]
   [ApiController]

   public class PedidoController : ControllerBase
      {
      private readonly PedidoContext _context;

      public PedidoController(PedidoContext context)
         {
         _context = context;
         }

      // GET: api/Pedido
      [HttpGet]
      public async Task<ActionResult<IEnumerable<Pedido>>> GetPedido()
         {
         return await _context.Pedido.ToListAsync();
         }

      // GET: api/Pedido/5
      [HttpGet("{TBPedidoID}")]
      public async Task<ActionResult<Pedido>> GetPedido(long TBPedidoID)
         {
         var Pedido = await _context.Pedido.FindAsync(TBPedidoID);

         if (Pedido == null)
            {
            return NotFound();
            }

         return Pedido;
         }

      // PUT: api/Pedidos/5
      [HttpPut("{TBPedidoID}")]
      public async Task<IActionResult> PutPedido(long TBPedidoID, Pedido Pedido)
         {
         if (TBPedidoID != Pedido.TBPedidoID)
            {
            return BadRequest();
            }

         _context.Entry(Pedido).State = EntityState.Modified;

         try
            {
            await _context.SaveChangesAsync();
            }
         catch (DbUpdateConcurrencyException)
            {
            if (!PedidoExists(TBPedidoID))
               {
               return NotFound();
               }
            else
               {
               throw;
               }
            }

         return NoContent();
         }

      // POST: api/Pedido+
      [HttpPost]
      public async Task<ActionResult<Pedido>> PostPedido(Pedido Pedido)
         {
         _context.Pedido.Add(Pedido);
         await _context.SaveChangesAsync();

         return CreatedAtAction(nameof(GetPedido), new { TBPedidoID = Pedido.TBPedidoID }, Pedido);
         }

      // DELETE: api/Pedidos/5
      [HttpDelete("{TBPedidoID}")]
      public async Task<ActionResult<Pedido>> DeletePedido(long TBPedidoID)
         {
         var Pedido = await _context.Pedido.FindAsync(TBPedidoID);
         if (Pedido == null)
            {
            return NotFound();
            }

         _context.Pedido.Remove(Pedido);
         await _context.SaveChangesAsync();

         return Pedido;
         }

      private bool PedidoExists(long TBPedidoID)
         {
         return _context.Pedido.Any(e => e.TBPedidoID == TBPedidoID);
         }

      } // PedidosController

   } // APITest.Controllers
