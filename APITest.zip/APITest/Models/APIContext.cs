﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APITest.Models
   {
   public class AdicionalContext : DbContext
      {
      public AdicionalContext(DbContextOptions<AdicionalContext> options)
          : base(options)
         {
         } // AdicionalContext

      public DbSet<Adicional> Adicional { get; set; }
      } // AdicionalContext : DbContext

   public class PedidoContext : DbContext
      {
      public PedidoContext(DbContextOptions<PedidoContext> options)
          : base(options)
         {
         } // PedidoContext

      public DbSet<Pedido> Pedido { get; set; }
      } // PedidoContext : DbContext

   public class PedidoAdicionaisContext : DbContext
      {
      public PedidoAdicionaisContext(DbContextOptions<PedidoAdicionaisContext> options)
          : base(options)
         {
         } // PedidoAdicionaisContext

      public DbSet<PedidoAdicionais> PedidoAdicionais { get; set; }
      } // PedidoAdicionaisContext : DbContext

   public class SaborContext : DbContext
      {
      public SaborContext(DbContextOptions<SaborContext> options)
          : base(options)
         {
         } // SaborContext

      public DbSet<Sabor> Sabor { get; set; }
      } // SaborContext : DbContext

   public class TamanhoContext : DbContext
      {
      public TamanhoContext(DbContextOptions<TamanhoContext> options)
          : base(options)
         {
         } // TamanhoContext

      public DbSet<Tamanho> Tamanho { get; set; }
      } // TamanhoContext : DbContext

   } // APITest.Models
