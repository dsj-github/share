﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace APITest.Models
   {
      public class Adicional
         {
         [Key]
         public long TBAdicionalID { get; set; }
         public string TBAdicionalDesc { get; set; }
         public int TBAdicionalTempo { get; set; }
         public decimal TBAdicionalValor { get; set; }
         } // Adicional

      public class Pedido
         {
         [Key]
         public long TBPedidoID { get; set; }
         public long TBPedidoTamanho { get; set; }
         public long TBPedidoSabor { get; set; }
         public int TBPedidoTempo { get; set; }
         public decimal TBPedidoValor { get; set; }
         } // pedido

      public class PedidoAdicionais
         {
         [Key]
         public long TBPedidoAdicionaisID { get; set; }
         public long TBPedidoID { get; set; }
         public long TBAdicionalID { get; set; }
         public int TBPedidoAdicionaisTempo { get; set; }
         public decimal TBPedidoAdicionaisValor { get; set; }
         } // PedidoAdicionais

      public class Sabor
         {
         [Key]
         public long TBSaborID { get; set; }
         public string TBSaborDesc { get; set; }
         public int TBSaborTempo { get; set; }
         public decimal TBSaborValor { get; set; }
         } // Sabor

      public class Tamanho
         {
         [Key]
         public long TBTamanhoID { get; set; }
         public string TBTamanhoDesc { get; set; }
         public int TBTamanhoTempo { get; set; }
         public decimal TBTamanhoValor { get; set; }
         } // Tamanho

   } // APITest.Models
